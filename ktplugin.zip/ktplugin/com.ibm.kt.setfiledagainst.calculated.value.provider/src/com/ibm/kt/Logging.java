/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2010. All Rights Reserved. 
 * 
 * Note to U.S. Government Users Restricted Rights:  Use, 
 * duplication or disclosure restricted by GSA ADP Schedule 
 * Contract with IBM Corp.
 *******************************************************************************/
package com.ibm.kt;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import com.ibm.team.foundation.common.util.FoundationLog;

/**
 * Eclipse bundles can optionally contain an activation singleton that is
 * invoked when the bundle is first loaded, usually lazily as in this case. This
 * activator does not do anything interesting on start or stop. However, it is
 * also common practice to have the activation class provide some basic common
 * services that are needed by other classes in your bundle. In the case here,
 * we have common error logging methods for use by the classes in the bundle.
 */
public class Logging implements BundleActivator {
	
	/*
	 * Defining a constant for the bundle id is common practice.
	 */
	public static final String PLUGIN_ID = "com.ibm.kt.setfiledagainst.calculated.value.provider";

	/*
	 * The Eclipse runtime creates the singleton using the default constructor and
	 * calls the start method. The singleton is cached here.
	 */
	private static Logging fgPlugin;
	
	private static BundleContext context;

	/**
	 * The default constructor is used by Eclipse to create the singleton.
	 */
	public Logging() {
	}
	
	static BundleContext getContext() {
		return context;
	}

	/**
	 * After construction, Eclipse calls this method. The base class method must
	 * be called first and then we cache this instance.
	 */
	public void start(BundleContext bundleContext) throws Exception {
		Logging.context = bundleContext;
		fgPlugin = this;
	}

	/**
	 * Called by Eclipse if the bundle is to be unloaded. The call to the base
	 * class method must be last. The cached singleton is forgotten.
	 */
	public void stop(BundleContext bundleContext) throws Exception {
		fgPlugin = null;
		Logging.context = null;
	}

	/**
	 * Other classes in the bundle get the singleton via this method.
	 * 
	 * @return the shared instance
	 */
	public static Logging getDefault() {
		return fgPlugin;
	}

	/**
	 * Classes in the bundle use this method to easily log messages in a
	 * consistent manner.
	 * 
	 * @param message
	 *            the message to log
	 * @param exception
	 *            the exception that caused the problem
	 */
	public void log(String message, Throwable exception) {
		FoundationLog.getLog(PLUGIN_ID).error(message, exception);
	}

}
