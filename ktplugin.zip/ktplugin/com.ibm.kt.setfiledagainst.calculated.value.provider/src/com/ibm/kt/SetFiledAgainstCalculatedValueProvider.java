/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2013. All Rights Reserved. 
 *
 * Note to U.S. Government Users Restricted Rights:  Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *******************************************************************************/
package com.ibm.kt;

import java.util.Arrays;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.ibm.team.process.common.IProjectArea;
import com.ibm.team.repository.common.IContributor;
import com.ibm.team.repository.common.IContributorHandle;
import com.ibm.team.repository.common.TeamRepositoryException;
import com.ibm.team.workitem.common.IAuditableCommon;
import com.ibm.team.workitem.common.IWorkItemCommon;
import com.ibm.team.workitem.common.internal.attributeValueProviders.IConfiguration;
import com.ibm.team.workitem.common.internal.attributeValueProviders.IValueProvider;
import com.ibm.team.workitem.common.model.IAttribute;
import com.ibm.team.workitem.common.model.ICategory;
import com.ibm.team.workitem.common.model.ICategoryHandle;
import com.ibm.team.workitem.common.model.IWorkItem;
import com.ibm.team.workitem.common.model.ItemProfile;

/** 
 * This class sets the category in the filed against attribute of the work item.
 * It uses the name of the Owner of the work item as the basis for the category
 * name. Brackets such as () and asterisk are trimmed from the Owned By attribute
 * so that the resulting category name is of a standard and predictable format.
 * For example, a name such as "WARK, IAN S (Ian)" is changed to WarkIanS.
 * Similarly, a name such as "Lee, Dong Hun *PARTNER*" is changed to 
 * LeeDongHun.
 */
public class SetFiledAgainstCalculatedValueProvider implements IValueProvider<ICategory>  {

	public SetFiledAgainstCalculatedValueProvider() {
	}

	/**
	 * Obtains the work item owner, deduces a short name for it, and returns it as
	 * a ICategory value, so that it will be set in the Filed Against attribute.
	 * In this case the Filed Against attribute is not visible, but it exists nevertheless. 
	 * <br><br>
	 * 
	 * If no matching value is found, the Unassigned category is set. When this happens 
	 * anyone will be able to see that record, so we have set up a log which tells us 
	 * whenever there is no category that can be set. <br><br>
	 * 
	 * Note: We have set up a ContributorUtil class to share the algorithm which
	 * calculates the owner short name, because it needs to match exactly with the
	 * team area name and the category name.
	 * 
	 * @param attribute
	 * @param workItem
	 * @param workItemCommon
	 * @param workItemCommon
	 * @param configuration
	 * @param monitor
	 * @return the category associated with the owner, or the Unassigned category if 
	 * no matching category exists
	 * @throws TeamRepositoryException
	 */
	@Override
	public ICategory getValue(IAttribute attribute, IWorkItem workItem,
			IWorkItemCommon workItemCommon, IConfiguration configuration,
			IProgressMonitor monitor) throws TeamRepositoryException {
		
		IContributorHandle ownerHandle = workItem.getOwner();
		IAuditableCommon auditableCommon = workItemCommon.getAuditableCommon();
		
		if (ownerHandle instanceof IContributorHandle) {
		
			//fetch the full object to see things like IContributor.getName(), IContributor.getUserId(), etc...
			IContributor owner = (IContributor) auditableCommon.resolveAuditable(ownerHandle,ItemProfile.createFullProfile(IContributor.ITEM_TYPE), monitor);
			String fullname = ContributorUtil.deduceShortName(owner);
					
			// Resolve with full data to get the hierarchy
			IProjectArea projectArea = (IProjectArea) workItemCommon
				.getAuditableCommon().resolveAuditable(workItem.getProjectArea(),
						ItemProfile.PROJECT_AREA_FULL, monitor);
				
			// ready new category value.
			List<String> path= Arrays.asList((projectArea.getName() + "/" + fullname).split("/"));
			ICategoryHandle newCategoryHandle = workItemCommon.findCategoryByNamePath(workItem.getProjectArea(), path, monitor);
			
			if (newCategoryHandle == null) {
				if (!fullname.equals("Unassigned")) {
					Logging.getDefault().log("Missing Category: " + fullname, null);
				}
				return workItemCommon.findUnassignedCategory(attribute.getProjectArea(), ICategory.DEFAULT_PROFILE, monitor);
			}
		
			//return ICategory;
			return workItemCommon.getAuditableCommon().resolveAuditable(newCategoryHandle, ICategory.DEFAULT_PROFILE, monitor);
		}
		
		else {
			return workItemCommon.findUnassignedCategory(attribute.getProjectArea(), ICategory.DEFAULT_PROFILE, monitor);
		}
				
	}
}
