/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2013. All Rights Reserved. 
 *
 * Note to U.S. Government Users Restricted Rights:  Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *******************************************************************************/
package com.ibm.kt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;

import com.ibm.team.process.common.IProcessArea;
import com.ibm.team.process.common.IProcessAreaHandle;
import com.ibm.team.process.common.IRole;
import com.ibm.team.repository.common.IContributor;
import com.ibm.team.repository.common.IContributorHandle;
import com.ibm.team.repository.common.TeamRepositoryException;
import com.ibm.team.workitem.common.IAuditableCommonProcess;
import com.ibm.team.workitem.common.IWorkItemCommon;
import com.ibm.team.workitem.common.internal.attributeValueProviders.IConfiguration;
import com.ibm.team.workitem.common.model.IWorkItem;
import com.ibm.team.workitem.common.model.ItemProfile;

/**
 * Utility class to provide contributor related utilities
 *
 */
public class ContributorUtil {
	
	private static final String ADMINISTRATOR = "Administrator";
	static final String ROLE = "role";
	static final String PROCESSAREA = "processArea";


	/**
	 * Returns a list of members that have a certain role in the process area a work item is filed against
	 * 
	 * @param workItem
	 * @param lookupRoles
	 * @param workItemCommon
	 * @param monitor
	 * @return a list of contributor handles
	 * @throws TeamRepositoryException
	 */
	public static List<IContributor> findProcessAreaMembersByRole(IWorkItem workItem, Collection<String> lookupRoles,
			IWorkItemCommon workItemCommon, IProgressMonitor monitor)
			throws TeamRepositoryException {
		IProcessAreaHandle processAreaHandle = workItemCommon.findProcessArea(workItem, monitor);
		IProcessArea processArea = (IProcessArea) workItemCommon.getAuditableCommon().resolveAuditable(processAreaHandle,
				ItemProfile.PROCESS_AREA_DEFAULT,monitor);
		IAuditableCommonProcess auditableCommonProcess= workItemCommon.getAuditableCommon().getProcess(processArea, monitor);
		IContributorHandle[] userhandles = auditableCommonProcess.getContributorsWithRole(processArea.getMembers(), processArea, lookupRoles.toArray(new String[lookupRoles.size()]), monitor);
		return workItemCommon.getAuditableCommon().resolveAuditables(Arrays.asList(userhandles), ItemProfile.CONTRIBUTOR_DEFAULT, monitor);
	}
	
	/**
	 * Returns true if the user working on the work item has a specified role in the process area 
	 * the work item is filed against
     *
	 * @param workItem
	 * @param user
	 * @param lookupRoles
	 * @param workItemCommon
	 * @param monitor
	 * @return true if the user has the specified role, else false
	 * @throws TeamRepositoryException
	 */
	public static boolean hasRole(IWorkItem workItem, IContributorHandle user, List<String> lookupRoles,
			IWorkItemCommon workItemCommon, IProgressMonitor monitor)
			throws TeamRepositoryException {
		IProcessAreaHandle processAreaHandle = workItemCommon.findProcessArea(workItem, monitor);
		IProcessArea processArea = (IProcessArea) workItemCommon.getAuditableCommon().resolveAuditable(processAreaHandle,
				ItemProfile.PROCESS_AREA_DEFAULT,
				monitor);
		IAuditableCommonProcess auditableCommonProcess= workItemCommon.getAuditableCommon().getProcess(processArea, monitor);
		Collection<IRole> roles = auditableCommonProcess.getContributorRoles(user, processArea, monitor);
		for (IRole aRole : roles) {
			if(lookupRoles.contains(aRole.getId())){
				return true;
			}
		}
		return false;
	}

	/**
	 * Reads the role configuration
	 * 
	 * Configure in Process XML
	 * <processArea role="Administrator"/>
	 * 
	 * @param configuration
	 * @return any role configured, else Administrator
	 */
	public static List<String> getConfiguration(IConfiguration configuration) {
		ArrayList<String>lookupRoles=new ArrayList<String>();
	
		List<IConfiguration> processAreaConfigurations= configuration.getChildren(PROCESSAREA);
		if(null!=processAreaConfigurations&&!processAreaConfigurations.isEmpty()){ // We got a configuration
			for (IConfiguration roleConfiguration : processAreaConfigurations) {
				String foundRole=roleConfiguration.getString(ROLE);
				if(foundRole!=null){
					lookupRoles.add(foundRole);
				}
			}
		} else {
			lookupRoles.add(ADMINISTRATOR);
		}
		return lookupRoles;
	}
	
	/**
	 * Deduces the short name of the owner. This is used for the category and the team area names. 
	 * Information in round brackets or within asterisks is removed. The first letter of each word 
	 * is capitalised and all non-alphanumeric information is removed.
     *
	 * @param owner
	 * @return the short name of the owner
	 */
	public static String deduceShortName (IContributor owner) {
		
		String fullname = owner.getName();

		//Remove any text in () brackets and inside * * asterisks.
		if (fullname.indexOf("(") > -1) {
		    fullname = fullname.substring(0,fullname.indexOf("("));
		}
		if (fullname.indexOf("*") > -1) {
		    fullname = fullname.substring(0,fullname.indexOf("*"));
		}
		
		//We need to make the first letter of each word upper case and the rest lower case
		fullname = capitalizeFirstLetter(fullname);
		
		//We need to remove anything left that is not alphanumeric.. e.g. comma, space, period, special chars
		fullname = fullname.replaceAll("[^A-Za-z0-9]", "");
		
		return fullname;
	}
	
	private static String capitalizeFirstLetter(String str) {
		
	    String[] pieces = str.split(" ");
	    for (int i=0; i < pieces.length; i++) {
	        char j = Character.toUpperCase(pieces[i].charAt(0));
	        if (pieces[i].length() > 1) {
	            pieces[i] = j + pieces[i].substring(1).toLowerCase();
	        }
	        else {
	            pieces[i] = String.valueOf(Character.toUpperCase(j));
	        }
	    }
	    return joinStr(pieces,0,"");
	}
	
	private static String joinStr(String[] strings, int startIndex, String separator) {
		
	    StringBuffer sb = new StringBuffer();
	    for (int i=startIndex; i < strings.length; i++) {
	    	if (i != startIndex) {
	    		sb.append(separator);
	    	}
	        sb.append(strings[i]);
	    }
	    return sb.toString();
	}
}
