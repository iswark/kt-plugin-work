/*******************************************************************************
 * Licensed Materials - Property of IBM
 * (c) Copyright IBM Corporation 2013. All Rights Reserved. 
 *
 * Note to U.S. Government Users Restricted Rights:  Use, duplication or 
 * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
 *******************************************************************************/
package com.ibm.kt;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;

import com.ibm.team.process.common.IProjectArea;
import com.ibm.team.process.common.ITeamArea;
import com.ibm.team.process.common.ITeamAreaHandle;
import com.ibm.team.repository.common.IContributor;
import com.ibm.team.repository.common.IContributorHandle;
import com.ibm.team.repository.common.TeamRepositoryException;
import com.ibm.team.workitem.common.IWorkItemCommon;
import com.ibm.team.workitem.common.internal.attributeValueProviders.IConfiguration;
import com.ibm.team.workitem.common.internal.attributeValueProviders.IValidator;
import com.ibm.team.workitem.common.model.IAttribute;
import com.ibm.team.workitem.common.model.IWorkItem;
import com.ibm.team.workitem.common.model.ItemProfile;

/**
 * Validates if the logged in user has permission to save the work
 * item against the person indicated in the Owned By attribute. In
 * most cases, this is the KT student. <br><br>
 * 
 * The severity of the message is error by default, but can be 
 * changed to warning. When the message is set to warning it effectively
 * turns it off, since warnings are neither displayed, nor do they 
 * change the behaviour. It is also possible to configure two contacts
 * to notify when requesting permission to perform the save.<br><br>
 * {@code <validator id="aaa" name="bbb"}
 * {@code providerId="com.ibm.kt.InformWhenOwnerIsNotOwnStudent">}<br>
 * {@code <configuration contactPerson1="xxx" contactPerson2="yyy"}
 * {@code severity="warning"/>}<br>
 * {@code </validator>}
 */
public class InformWhenOwnerIsNotOwnStudent implements IValidator {

	private static final String CONTACT_PERSON1 = "contactPerson1";
	private static final String CONTACT_PERSON2 = "contactPerson2";
	private static final String WARNING_LEVEL = "warning";
	private static final String SEVERITY = "severity";
	private static final String CONFIGURATION = "configuration";

	private String contactPerson1;
	private String contactPerson2;
	private int validationSeverity;

	public InformWhenOwnerIsNotOwnStudent() {
	}

	@SuppressWarnings("unchecked")
	@Override
	public IStatus validate(IAttribute attribute, IWorkItem workItem,
			IWorkItemCommon workItemCommon, IConfiguration configuration,
			IProgressMonitor monitor) throws TeamRepositoryException {
		
		getConfiguration(configuration);
		
		//We are validating that there is an appropriate owner is set. 
		//Ticket review work items and One-On-One work items both have a Owned By attribute. 
		//The owner is the person BEING reviewed and the person receiving a 1-1. Not the other way around.
		IContributorHandle ownerHandle = (IContributorHandle) attribute
				.getValue(workItemCommon.getAuditableCommon(), workItem, monitor);
		
		//fetch the full object to see things like IContributor.getName(), IContributor.getUserId(), etc...
		IContributor owner = (IContributor) workItemCommon.getAuditableCommon()
				.resolveAuditable(ownerHandle,ItemProfile.createFullProfile(IContributor.ITEM_TYPE), monitor);
		
		IProjectArea projectArea = (IProjectArea) workItemCommon.getAuditableCommon()
				.resolveAuditable(workItem.getProjectArea(), ItemProfile.PROJECT_AREA_FULL, monitor);

		IContributorHandle userHandle = workItemCommon.getAuditableCommon().getUser();
		
		@SuppressWarnings("rawtypes")
		List lookupRoles = ContributorUtil.getConfiguration(configuration);
		if (ContributorUtil.hasRole(workItem, userHandle, lookupRoles, workItemCommon, monitor)) {
			//If the user has the Administrator role in the project area, do not report error.
			//Note that if the user is not a JazzAdmin, they will still get permission errors if not a 
			//member or administrator of the owner's team area.
			return new Status(IStatus.OK, "com.ibm.kt.InformWhenOwnerIsNotOwnStudent", 
					"Confirmed permission to save records against " + owner.getName());
		}

		List<ITeamAreaHandle> teamAreaHandle = projectArea.getTeamAreas();
		List<ITeamArea> teamArea = workItemCommon.getAuditableCommon()
				.resolveAuditables(teamAreaHandle, ItemProfile.TEAM_AREA_DEFAULT, monitor);
		for (ITeamArea ta: teamArea){
			if (ta.getName() != null && ta.getName().equals(ContributorUtil.deduceShortName(owner)) 
					&& ta.hasMember(owner) && ta.hasMember(userHandle)){
				
				//If the team area belongs to the owner and has both the owner and the user, then
				//the user has permission to save
				return new Status(IStatus.OK, "com.ibm.kt.InformWhenOwnerIsNotOwnStudent", 
						"Confirmed permission to save records against " + owner.getName());
			}
		}
		
		//We didn't find a team area with both the owner and the user, so the user does not have permission to save.
		StringBuffer sbErrorMsg = new StringBuffer();
		sbErrorMsg.append("You do not have permission to save records against ");
		sbErrorMsg.append(owner.getName());
		sbErrorMsg.append(". If you believe you should have this permission, please contact ");
		sbErrorMsg.append(contactPerson1);
		sbErrorMsg.append(" or ");
		sbErrorMsg.append(contactPerson2);
		sbErrorMsg.append(" to have yourself added to the relevant team area.");
		
		//fetch the full user to see the user name in log message
		IContributor user = (IContributor) workItemCommon.getAuditableCommon()
				.resolveAuditable(userHandle,ItemProfile.createFullProfile(IContributor.ITEM_TYPE), monitor);
		
		Logging.getDefault().log("Validation Failed: User = " + user.getName() + " Owner = " + owner.getName(), null);
		return new Status(validationSeverity, "com.ibm.kt.InformWhenOwnerIsNotOwnStudent", sbErrorMsg.toString());
	}

	/**
	 * Obtains the configuration and sets the contacts it finds in the displayed
	 * error message. If there is no one set in the configuration it sets Ian Wark 
	 * and Anthony Corrente as contacts. Also sets the severity parameter, which
	 * turns this validation message on and off.
	 * 
	 * @param configuration the xml configuration for this project area
	 */
	private void getConfiguration(IConfiguration configuration) {
		
		contactPerson1 = "Ian Wark (ianwark@au1.ibm.com)";
		contactPerson2 = "Anthony Corrente (anthony.corrente@au1.ibm.com)";
		validationSeverity = IStatus.ERROR;
		IConfiguration parameters= configuration.getChild(CONFIGURATION);
		
		if (null != parameters){ // We got a configuration
			
			String contact1 = parameters.getString(CONTACT_PERSON1);
			String contact2 = parameters.getString(CONTACT_PERSON2);
			String configuredSeverity = parameters.getString(SEVERITY);
			
			if (null != contact1){
				contactPerson1 = contact1;
			}
			
			if (null != contact2){
				contactPerson2 = contact2;
			}
			
			if (null != configuredSeverity){
				validationSeverity =  configuredSeverity
						.equalsIgnoreCase(WARNING_LEVEL)? IStatus.WARNING: IStatus.ERROR;
			}
		}
	}
}